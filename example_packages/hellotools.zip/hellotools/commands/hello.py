import os, sys
here = os.path.dirname(__file__)
root = os.path.abspath(os.path.join(here, ".."))
if root not in sys.path:
    sys.path.insert(0, root)

from lib.greetings import hello

def main(argv):
    print(hello())

if __name__ == "__main__":
    main(sys.argv[1:])
