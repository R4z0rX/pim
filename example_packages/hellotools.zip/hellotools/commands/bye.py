def main(argv):
    print("Goodbye from hellotools!")

if __name__ == "__main__":
    import sys
    main(sys.argv[1:])
