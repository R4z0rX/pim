def hello():
    return "Hello from hellotools!"
